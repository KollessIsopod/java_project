package projectPackage;
import java.io.Serializable;

public class Individual extends Subscriber implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String creditCardNr;
	private int expireMonth, expireYear, cvv;
	
	public Individual(String name, String address, String creditCardNr, int expireMonth, int expireYear, int cvv) {
		super(name, address);
		this.creditCardNr = creditCardNr;
		this.expireMonth = expireMonth;
		this.expireYear = expireYear;
		this.cvv = cvv;
	}

	@Override
	public String getBillingInformation() {
		return "Individual [CreditCardNr=" + creditCardNr + "\nExpireMonth=" + expireMonth + "\nExpireYear="
				+ expireYear + "\nCVV=" + cvv + "]";
	}


	
	
}
