package projectPackage;
import java.io.Serializable;

public class Subscription implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private final Journal journal;
    private final Subscriber subscriber;
    private final DateInfo dates;
    private int copies;
    private PaymentInfo payment;
    
    public Subscription(Journal journal, Subscriber subscriber, DateInfo dates, int copies, PaymentInfo payment) {
        this.journal = journal;
        this.subscriber = subscriber;
        this.dates = dates;
        this.copies = copies;
        this.payment = payment;
    }

    public Journal getJournal() {
        return journal;
    }

    public Subscriber getSubscriber() {
        return subscriber;
    }

	public DateInfo getDates() {
		return dates;
	}

	public int getCopies() {
		return copies;
	}

	public void setCopies(int copies) {
		this.copies = copies;
	}

	public PaymentInfo getPayment() {
		return payment;
	}

	public void acceptPayment(double amount) {
		payment.increasePayment(amount);
        System.out.println("Current Balance " + payment.getReceivedPayment());
	}
	
	public boolean canSend(int issueMonth) {
		
		
		
		double i = journal.getIssuePrice()*payment.getDiscountRatio()*issueMonth;
		if(payment.getReceivedPayment() >= i) {			
			System.out.println("Can send. Balance:" + payment.getReceivedPayment() + "Required:" + i +"Ratio:"+ payment.getDiscountRatio());
			return true ;
		} else {
			System.out.println("CanNOT send. :(");
			return false;
		}
	}
	
}