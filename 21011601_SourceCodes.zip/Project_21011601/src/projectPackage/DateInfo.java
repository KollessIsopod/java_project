package projectPackage;
import java.io.Serializable;

public class DateInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int startMonth, startYear, endMonth, endYear;

	public DateInfo(int startMonth, int startYear, int endMonth, int endYear) {
		this.startMonth = startMonth;
		this.startYear = startYear;
		this.endMonth = endMonth;
		this.endYear = endYear;
	}

	
	
	public int getStartMonth() {
		return startMonth;
	}
	public int getStartYear() {
		return startYear;
	}
	public int getEndMonth() {
		return endMonth;
	}
	public int getEndYear() {
		return endYear;
	}



	public String getDates() {
		return "DateInfo [Start date=" + startMonth + "/" + startYear + " | End date=" + endMonth
				+ "/" + endYear + "]";
	}


}
