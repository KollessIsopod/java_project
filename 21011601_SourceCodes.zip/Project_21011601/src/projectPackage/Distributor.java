package projectPackage;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

import javax.swing.JOptionPane;

import java.io.*;
import java.io.Serializable;


public class Distributor implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	Vector<Subscriber> subscribers = new Vector<>();
    Hashtable<String, Journal> journals = new Hashtable<>();
    Vector<Subscription> subscriptions = new Vector<>();
    Vector<PaymentInfo> payments = new Vector<>();
    Vector<DateInfo> dates = new Vector<>();

	public Distributor() {	}

    public boolean addJournal(Journal magazine) {
    	
        String journalKey = magazine.getIssn();
    	
    	if (!journals.containsKey(journalKey)) {
    		journals.put(journalKey, magazine);
            return true; 
        } else {
            return false; //already exists
        }
    }
    
    public Journal searchJournal(String searchKey) {
        return journals.get(searchKey);
    }
    
    public boolean addSubscriber(Subscriber subscriber) {
    	String key1 = subscriber.getName();
    	String key2 = subscriber.getAddress();
    	
    	for (Subscriber subscriberfinder : subscribers) {
            if (String.valueOf(subscriberfinder.getName()).equals(key1) && String.valueOf(subscriberfinder.getAddress()).equals(key2)) {
                 return false;
            }
        }
    	
    	subscribers.add(subscriber);
        return true; // Subscriber added successfully
    }
    
    public Subscriber searchSubscriber(String searchKey) {
        for (Subscriber subscriber : subscribers) {
            if (String.valueOf(subscriber.getName()).equals(searchKey)) {
                return subscriber;
            }
        }
        return null;
    }

    public boolean addDates(DateInfo date) {
    	dates.add(date);
        return true; // Dates added successfully
    }
    
    public boolean addPayments(PaymentInfo payment) {
    	payments.add(payment);
        return true; // Payments added successfully
    }
    
    public Subscription findSubscription(Subscriber subscriber, Journal journal) {
        // Iterate through existing subscriptions to find a matching one
        for (Subscription subscription : subscriptions) {
            if (subscription.getSubscriber() == subscriber && subscription.getJournal() == journal) {
                return subscription;
            }
        }
        return null; // No matching subscription found
    }
    
    public boolean addSubscription(Journal journal, Subscriber subscriber, Subscription subscription){
    	
        Subscription newsubscription = findSubscription(subscriber, journal);
    	
    	if (newsubscription != null) {
    		newsubscription.setCopies(newsubscription.getCopies() + subscription.getCopies());
            return false;
    		} else {
            Subscription newSubscription = new Subscription(journal, subscriber, subscription.getDates(), subscription.getCopies(), subscription.getPayment());
            subscriptions.add(newSubscription);
            return true;
    		}
    }
    
    public void listAllSendingOrders(int currentMonth, int currentYear) {
        StringBuilder resultStringBuilder = new StringBuilder();

        resultStringBuilder.append("[!] Listing all sending orders...\n");

        for (Subscription subscription : subscriptions) {
            if (subscription.getDates().getStartYear() < currentYear || subscription.getDates().getEndYear() > currentYear) {

                if (subscription.canSend(currentMonth))
                    resultStringBuilder.append("[+] Order: ").append(subscription.getCopies()).append(" ")
                            .append(subscription.getJournal().getName()).append("->")
                            .append(subscription.getSubscriber().getName()).append("| Billing Information:")
                            .append(subscription.getSubscriber().getBillingInformation()).append("\n");

            } else if (subscription.getDates().getStartYear() == currentYear &&
                    subscription.getDates().getStartMonth() < currentMonth) {

                if (subscription.canSend(currentMonth))
                    resultStringBuilder.append("[+] Order: ").append(subscription.getCopies()).append(" ")
                            .append(subscription.getJournal().getName()).append("->")
                            .append(subscription.getSubscriber().getName()).append("| Billing Information:")
                            .append(subscription.getSubscriber().getBillingInformation()).append("\n");

            } else if (subscription.getDates().getEndYear() == currentYear &&
                    subscription.getDates().getEndMonth() > currentMonth) {

                if (subscription.canSend(currentMonth))
                    resultStringBuilder.append("[+] Order: ").append(subscription.getCopies()).append(" ")
                            .append(subscription.getJournal().getName()).append("->")
                            .append(subscription.getSubscriber().getName()).append("| Billing Information:")
                            .append(subscription.getSubscriber().getBillingInformation()).append("\n");
            }
        }

        if (subscriptions.isEmpty()) {
            resultStringBuilder.append("[-] Empty Subscriptions List.\n");
        }

        String result = resultStringBuilder.toString().trim();

        if (result.isEmpty()) {
            result = "No sending orders found.";
        }

        JOptionPane.showMessageDialog(null, result, "All Sending Orders Information", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void listSendingOrders(String issn, int currentMonth, int currentYear) {
        StringBuilder resultStringBuilder = new StringBuilder();

        resultStringBuilder.append("[!] Listing specified orders...\n");

        for (Subscription subscription : subscriptions) {
            if (subscription.getJournal().getIssn().equals(issn)) {
                if (subscription.getDates().getStartYear() < currentYear || subscription.getDates().getEndYear() > currentYear) {

                    if (subscription.canSend(currentMonth))
                        resultStringBuilder.append("[+] Order: ").append(subscription.getCopies()).append(" ")
                                .append(subscription.getJournal().getName()).append("->")
                                .append(subscription.getSubscriber().getName()).append("| Billing Information:")
                                .append(subscription.getSubscriber().getBillingInformation()).append("\n");

                } else if (subscription.getDates().getStartYear() == currentYear &&
                        subscription.getDates().getStartMonth() < currentMonth) {

                    if (subscription.canSend(currentMonth))
                        resultStringBuilder.append("[+] Order: ").append(subscription.getCopies()).append(" ")
                                .append(subscription.getJournal().getName()).append("->")
                                .append(subscription.getSubscriber().getName()).append("| Billing Information:")
                                .append(subscription.getSubscriber().getBillingInformation()).append("\n");

                } else if (subscription.getDates().getEndYear() == currentYear &&
                        subscription.getDates().getEndMonth() > currentMonth) {

                    if (subscription.canSend(currentMonth))
                        resultStringBuilder.append("[+] Order: ").append(subscription.getCopies()).append(" ")
                                .append(subscription.getJournal().getName()).append("->")
                                .append(subscription.getSubscriber().getName()).append("| Billing Information:")
                                .append(subscription.getSubscriber().getBillingInformation()).append("\n");
                }
            }
        }

        if (subscriptions.isEmpty()) {
            resultStringBuilder.append("[-] Empty Subscriptions List.\n");
        }

        String result = resultStringBuilder.toString().trim();

        if (result.isEmpty()) {
            result = "No orders found for the given parameters.";
        }

        JOptionPane.showMessageDialog(null, result, "Sending Orders Information", JOptionPane.INFORMATION_MESSAGE);
    }

    
    public void IncompletePayments() {
        StringBuilder resultStringBuilder = new StringBuilder();

        for (Subscription subscription : subscriptions) {
            if (!subscription.canSend(1)) {
                resultStringBuilder.append("[!] Incomplete Payment: ").append(subscription.getJournal().getName())
                        .append(" -> ").append(subscription.getSubscriber().getName())
                        .append(" | Current Balance: ").append(subscription.getPayment().getReceivedPayment())
                        .append(" | Number of Copies: ").append(subscription.getCopies())
                        .append(" | Minimum Required Balance: ").append(subscription.getJournal().getIssuePrice()*
                        		subscription.getPayment().getDiscountRatio()*subscription.getCopies())
                        .append("\n");
            }
        }

        String result = resultStringBuilder.toString().trim();

        if (result.isEmpty()) {
            result = "No incomplete payments found.";
        }

        JOptionPane.showMessageDialog(null, result, "Incomplete Payments", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void listSubscriptions(String subscriberName) {
        StringBuilder resultStringBuilder = new StringBuilder();

        for (Subscription subscription : subscriptions) {
            if (subscription.getSubscriber().getName().equals(subscriberName)) {
                resultStringBuilder.append(subscription.getJournal().getName()).append(" -> ")
                        .append(subscriberName).append("\n");
            }
        }

        String result = resultStringBuilder.toString().trim();

        if (result.isEmpty()) {
            result = "No subscriptions found for the given subscriber name.";
        }

        JOptionPane.showMessageDialog(null, result, "Subscription Information", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void listSubscriptions(String issn, boolean i) {
        StringBuilder resultStringBuilder = new StringBuilder();

        for (Subscription subscription : subscriptions) {
            if (subscription.getJournal().getIssn().equals(issn)) {
                resultStringBuilder.append(subscription.getJournal().getIssn()).append(" -> ")
                        .append(subscription.getSubscriber().getName()).append("\n");
            }
        }

        String result = resultStringBuilder.toString().trim();

        if (result.isEmpty()) {
            result = "No subscriptions found for the given ISSN.";
        }

        JOptionPane.showMessageDialog(null, result, "Subscription Information", JOptionPane.INFORMATION_MESSAGE);
    }
    
    
    
    public void saveState(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(subscribers);
            oos.writeObject(journals);
            oos.writeObject(dates);
            oos.writeObject(payments);           
            oos.writeObject(subscriptions);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
	public void loadState(String filename) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            subscribers = (Vector<Subscriber>) ois.readObject();        
            journals = (Hashtable<String, Journal>) ois.readObject();
            dates = (Vector<DateInfo>) ois.readObject();
            payments = (Vector<PaymentInfo>) ois.readObject();
            subscriptions = (Vector<Subscription>) ois.readObject();
            System.out.println("Load Successful.");

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Load Failure.");
            e.printStackTrace();
        }
    }
    
    
    public void report(final int month, final int year, final int annual1, final int annual2) {
        
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(new Runnable() {
			@Override
			public void run() {
		        StringBuilder resultStringBuilder = new StringBuilder();
			    resultStringBuilder = generateSubscriptionExpiryReport(resultStringBuilder,month, year);
			    resultStringBuilder = generateAnnualPaymentsReport(resultStringBuilder, annual1 ,annual2);
			    String result = resultStringBuilder.toString().trim();

			    if (result.isEmpty()) {
			    	result = "This report has nothing to display.";
			    }

			    JOptionPane.showMessageDialog(null, result, "Requested Report", JOptionPane.INFORMATION_MESSAGE);			    
  
			}
		});
        

        
        executorService.shutdown();
    }
    
    private StringBuilder generateSubscriptionExpiryReport(StringBuilder myString, int month, int year) {
    	
    	boolean flag;
    	
    	myString.append("\nTo be expired:\n");
    	
    	for (Subscription subscription : subscriptions) {
    		flag=false;
            if(subscription.getDates().getEndYear() < year) {
            	flag = true;
            } else if(subscription.getDates().getEndYear() == year && subscription.getDates().getEndMonth() < month) {
            	flag = true;
            }
            
            if(flag == true) {
            	myString.append(subscription.getJournal().getName()).append(" -> ").append(subscription.getSubscriber().getName())
            	.append(" | ").append(subscription.getDates().getDates());
            }
            myString.append("\n");
        }
    	
    	
    	return myString;
    }

    private StringBuilder generateAnnualPaymentsReport(StringBuilder myString, int annual1, int annual2) {
        int month, year;
        boolean flag;
        int startMonth, startYear, endMonth, endYear;
        int annualIncome = 0, issueNumber;
        Map<Integer, Integer> years = new HashMap<>();

        for (Subscription subscription : subscriptions) {
            flag = false;
            issueNumber = 0;

            if (subscription.getDates().getStartYear() <= annual2 || subscription.getDates().getEndYear() >= annual1) {
                startMonth = subscription.getDates().getStartMonth();
                startYear = subscription.getDates().getStartYear();
                endMonth = subscription.getDates().getEndMonth();
                endYear = subscription.getDates().getEndYear();

                for (year = annual1; year <= annual2; year++) {
                    annualIncome = 0;

                    for (month = 1; month <= 12; month++) {
                        if (year > startYear && year < endYear) {
                            flag = true;
                        } else if (year == startYear) {
                            if (month >= startMonth) {
                                issueNumber = month - startMonth + 1;
                                flag = true;
                            }
                        } else if (year == endYear) {
                            if (month <= endMonth) {
                                issueNumber = endMonth - month + 1;
                                flag = true;
                            }
                        }

                        if (flag && subscription.canSend(issueNumber)) {
                            annualIncome += subscription.getJournal().getIssuePrice()*subscription.getCopies();
                        }
                    }

                    if (flag) {
                        if (years.containsKey(year)) {
                            years.put(year, years.get(year) + annualIncome);
                        } else {
                            years.put(year, annualIncome);
                        }
                    }
                }
            }
        }

        myString.append("[!] Annual Payments Report:\n");

        for (Map.Entry<Integer, Integer> entry : years.entrySet()) {
            int currentYear = entry.getKey();
            int income = entry.getValue();

            myString.append("Year ").append(currentYear).append(": $").append(income).append("\n");
        }

        if (years.isEmpty()) {
            myString.append("No payments found in the specified year range.\n");
        }

        return myString;
    }
    

}
