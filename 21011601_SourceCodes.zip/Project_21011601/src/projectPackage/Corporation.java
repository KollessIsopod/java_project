package projectPackage;
import java.io.Serializable;

public class Corporation extends Subscriber implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int bankCode, accountNumber;
	private int issueDay, issueMonth, issueYear;
	private String bankName;
	
	public Corporation(String name, String address, int bankCode, int accountNumber, int issueDay, int issueMonth,
			int issueYear, String bankName) {
		super(name, address);
		this.bankCode = bankCode;
		this.accountNumber = accountNumber;
		this.issueDay = issueDay;
		this.issueMonth = issueMonth;
		this.issueYear = issueYear;
		this.bankName = bankName;
	}

	@Override
	public String getBillingInformation() {
		return "Corporation [bankCode=" + bankCode + "\n AccountNumber=" + accountNumber + "\nIssueDay=" + issueDay
				+ "\nIssueMonth=" + issueMonth + "\nIssueYear=" + issueYear + "\nBankName=" + bankName + "]";
	}

	
	
	
	
	
}
