package projectPackage;
import java.io.Serializable;


public class Journal implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name, issn;
	@SuppressWarnings("unused")
	private int frequency;
	private double issuePrice;
	
	public Journal(String name, String issn, int frequency, double issuePrice) {
		super();
		this.name = name;
		this.issn = issn;
		this.frequency = frequency;
		this.issuePrice = issuePrice;
	}

	public String getIssn() {
		return issn;
	}

	public double getIssuePrice() {
		return issuePrice;
	}

	public String getName() {
		return name;
	}
	
	public int getFrequency() {
		return frequency;
	}

	
}
