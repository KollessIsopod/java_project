package projectPackage;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unused")
	public static void main(String[] args) {

		Distributor distributor = new Distributor();
        Vector<Subscriber> subscribers = distributor.subscribers;
        Hashtable<String, Journal> journals = distributor.journals;
        Vector<Subscription> subscriptions = distributor.subscriptions;
        Vector<PaymentInfo> payments = distributor.payments;
        Vector<DateInfo> dates = distributor.dates;
        System.out.println("-Start-");
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                createAndShowGUI();
            }
        });
	}

	
	private static void createAndShowGUI() {
        JFrame frame = new JFrame("Distributor GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 200);

        final Distributor distributor = new Distributor();

        JPanel panel = new JPanel();
        frame.getContentPane().add(panel);

        distributor.loadState("database.bat");

        
        JButton addSubscriberButton = new JButton("Add Subscriber");
        addSubscriberButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	String[] options = {"Individual", "Corporate"};
                int choice = JOptionPane.showOptionDialog(null, "Select subscriber type:", "Subscriber Type",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

                if (choice == 0) {
                    // Individual subscriber
                	 JPanel inputPanel = new JPanel(new GridLayout(0, 2));
                     JTextField nameField = new JTextField();
                     JTextField addressField = new JTextField();
                     JTextField creditCardField = new JTextField();
                     JTextField expireMonthField = new JTextField();
                     JTextField expireYearField = new JTextField();
                     JTextField cvvField = new JTextField();
                     
                     inputPanel.add(new JLabel("Name:"));
                     inputPanel.add(nameField);
                     inputPanel.add(new JLabel("Address:"));
                     inputPanel.add(addressField);
                     inputPanel.add(new JLabel("Credit Card No:"));
                     inputPanel.add(creditCardField);
                     inputPanel.add(new JLabel("Expire Month:"));
                     inputPanel.add(expireMonthField);
                     inputPanel.add(new JLabel("Expire Year:"));
                     inputPanel.add(expireYearField);
                     inputPanel.add(new JLabel("CVV:"));
                     inputPanel.add(cvvField);
                     
                     
                     int result = JOptionPane.showConfirmDialog(null, inputPanel,
                             "Enter Subscriber Information", JOptionPane.OK_CANCEL_OPTION);
                     
                     if (result == JOptionPane.OK_OPTION) {
                    	 
                         if (nameField.getText().isEmpty() || 
                             addressField.getText().isEmpty() || 
                             creditCardField.getText().isEmpty() ||
                        	 expireMonthField.getText().isEmpty() || 
                        	 expireYearField.getText().isEmpty() ||
                        	 cvvField.getText().isEmpty()) {
                             JOptionPane.showMessageDialog(null, "All fields are required to register an individual.",
                                     "Input Error", JOptionPane.ERROR_MESSAGE);
                             return;
                         } else {
                        	 
                        	 try {
                        	 Subscriber newsub = new Individual(nameField.getText(), addressField.getText(), creditCardField.getText(), 
                        			 Integer.valueOf(expireMonthField.getText()), Integer.valueOf(expireYearField.getText()), Integer.valueOf(cvvField.getText()));
                        	 
                        	 if(distributor.addSubscriber(newsub) == true) {
                                 JOptionPane.showMessageDialog(null, "Subscriber added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                                 return;
                        	 }else {
                        		 JOptionPane.showMessageDialog(null, 
                        				 "Subscriber with the same name & address exists.",
                                         "Duplicate Error", JOptionPane.ERROR_MESSAGE);
                        		 return;
                        	 }
                        	 
                        	 
                        	 } catch(NumberFormatException ex) {		 
                        		 JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid numeric values.",
                                         "Input Error", JOptionPane.ERROR_MESSAGE);
                        	 }
                         }
                     }
       
                } else if (choice == 1) {
                    // Corporate subscriber
                	JPanel inputPanel = new JPanel(new GridLayout(0, 2));
                    JTextField nameField = new JTextField();
                    JTextField addressField = new JTextField();
                    JTextField bankCodeField = new JTextField();
                    JTextField accountNumberField = new JTextField();
                    JTextField issueDayField = new JTextField();
                    JTextField issueMonthField = new JTextField();
                    JTextField issueYearField = new JTextField();
                    JTextField bankNameField = new JTextField();
                    
                    inputPanel.add(new JLabel("Name:"));
                    inputPanel.add(nameField);
                    inputPanel.add(new JLabel("Address:"));
                    inputPanel.add(addressField);
                    inputPanel.add(new JLabel("Bank Code:"));
                    inputPanel.add(bankCodeField);
                    inputPanel.add(new JLabel("Account Number:"));
                    inputPanel.add(accountNumberField);
                    inputPanel.add(new JLabel("Issue Day:"));
                    inputPanel.add(issueDayField);
                    inputPanel.add(new JLabel("Issue Month:"));
                    inputPanel.add(issueMonthField);
                    inputPanel.add(new JLabel("Issue Year:"));
                    inputPanel.add(issueYearField);
                    inputPanel.add(new JLabel("Bank Name:"));
                    inputPanel.add(bankNameField);
                    
                    int result = JOptionPane.showConfirmDialog(null, inputPanel,
                            "Enter Subscriber Information", JOptionPane.OK_CANCEL_OPTION);
                    
                    if (result == JOptionPane.OK_OPTION) {
                   	 
                        if (	nameField.getText().isEmpty() || 
                        		addressField.getText().isEmpty() || 
                        		bankCodeField.getText().isEmpty() ||
                        		accountNumberField.getText().isEmpty() || 
                        		issueDayField.getText().isEmpty() ||
                        		issueMonthField.getText().isEmpty() ||
                        		issueYearField.getText().isEmpty() || 
                        		bankNameField.getText().isEmpty()) {
                            JOptionPane.showMessageDialog(null, "All fields are required to register a corporate account.",
                                    "Input Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        } else {
                        	try {
                       	 Subscriber newsub = new Corporation(nameField.getText(), addressField.getText(), Integer.valueOf(bankCodeField.getText()),
                       			 Integer.valueOf(accountNumberField.getText()), Integer.valueOf(issueDayField.getText()), Integer.valueOf(issueMonthField.getText()),
                       			Integer.valueOf(issueYearField.getText()), bankNameField.getText());
                       	 
                       	 	
                       	     if(distributor.addSubscriber(newsub) == true) {
                                 JOptionPane.showMessageDialog(null, "Subscriber added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                                 return; 
                       	     }
                       	     
                        	} catch(NumberFormatException ex) {
                        		JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid numeric values.",
                                        "Input Error", JOptionPane.ERROR_MESSAGE);
                        	}
                        }
                    }
                    
                    // Call the method to add a corporate subscriber
                    // distributor.addCorporateSubscriber(name, address, bankCode, accountNumber, issueDay, issueMonth, issueYear, bankName);
                }
            }
        });

        JButton addJournalButton = new JButton("Add Journal");
        addJournalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	 JPanel inputPanel = new JPanel(new GridLayout(0, 2));
                 JTextField nameField = new JTextField();
                 JTextField issnField = new JTextField();
                 JTextField frequencyField = new JTextField();
                 JTextField issuePriceField = new JTextField();

                 inputPanel.add(new JLabel("Name:"));
                 inputPanel.add(nameField);
                 inputPanel.add(new JLabel("ISSN:"));
                 inputPanel.add(issnField);
                 inputPanel.add(new JLabel("Frequency:"));
                 inputPanel.add(frequencyField);
                 inputPanel.add(new JLabel("Issue Price:"));
                 inputPanel.add(issuePriceField);

                 int result = JOptionPane.showConfirmDialog(null, inputPanel,
                         "Enter Journal Information", JOptionPane.OK_CANCEL_OPTION);

                 if (result == JOptionPane.OK_OPTION) {
                     try {
                         String name = nameField.getText();
                         String issn = issnField.getText();
                         int frequency = Integer.parseInt(frequencyField.getText());
                         double issuePrice = Double.parseDouble(issuePriceField.getText());

                         Journal newJournal = new Journal(name, issn, frequency, issuePrice);
                         if(distributor.addJournal(newJournal) == true) {
                        	 JOptionPane.showMessageDialog(null, "Journal added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                             return;
                         } else {
                        	 JOptionPane.showMessageDialog(null, "Journal with same ISSN already exists.",
                                     "Duplicate Error", JOptionPane.ERROR_MESSAGE);
                         }
                     } catch (NumberFormatException ex) {
                         JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid numeric values.",
                                 "Input Error", JOptionPane.ERROR_MESSAGE);
                     }
                 }
            }
        });

        JButton addSubscriptionButton = new JButton("Add Subscription");
        addSubscriptionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	JPanel inputPanel = new JPanel(new GridLayout(0, 2));
            	JPanel inputPanel2 = new JPanel(new GridLayout(0, 2));
            	JPanel inputPanel3 = new JPanel(new GridLayout(0, 2));
                JTextField nameField = new JTextField();
                JTextField issnField = new JTextField();
                JTextField startMonthField = new JTextField();
                JTextField startYearField = new JTextField();
                JTextField discountRatioField = new JTextField();
                JTextField balanceField = new JTextField();
                JTextField copiesField = new JTextField();

                String subscriberInfo = null;
                String journalInfo = null;
                Journal journal = null;
                Subscriber subscriber = null;
                
                inputPanel.add(new JLabel("Subscriber Name:"));
                inputPanel.add(nameField);
               

                int result = JOptionPane.showConfirmDialog(null, inputPanel,
                        "Enter Subscriber's Information", JOptionPane.OK_CANCEL_OPTION);

                if (result == JOptionPane.OK_OPTION) {
                    	String name = nameField.getText();
                        subscriber = distributor.searchSubscriber(name);

                        if (subscriber == null) {
                            JOptionPane.showMessageDialog(null, "Subscriber not found!", "Search Result", JOptionPane.INFORMATION_MESSAGE);
                            return;
                        } else {
                            if (subscriber instanceof Individual) {
                                Individual individualSubscriber = (Individual) subscriber;
                                subscriberInfo = "Individual Subscriber:\nName: " + individualSubscriber.getName() +
                                        "\nAddress: " + individualSubscriber.getAddress() +
                                        individualSubscriber.getBillingInformation();
                            } else if (subscriber instanceof Corporation) {
                                Corporation corporateSubscriber = (Corporation) subscriber;
                                subscriberInfo = "Corporate Subscriber:\nName: " + corporateSubscriber.getName() +
                                        "\nAddress: " + corporateSubscriber.getAddress() +
                                        corporateSubscriber.getBillingInformation();
                            }
                        }
                        
                        
                }
                
                inputPanel2.add(new JLabel("Journal ISSN:"));
                inputPanel2.add(issnField);
                
                result = JOptionPane.showConfirmDialog(null, inputPanel2,
                        "Enter Journal's Information", JOptionPane.OK_CANCEL_OPTION);
                
                
                if (result == JOptionPane.OK_OPTION) {
                    String issn = issnField.getText();
                    journal = distributor.searchJournal(issn);
                    
                    if (journal == null) {
                        JOptionPane.showMessageDialog(null, "Journal not found! :(", "Search Result", JOptionPane.INFORMATION_MESSAGE);	
                        return;
                } else {
                    journalInfo = "Journal: \nName:" + journal.getName() + "\nISSN:" + journal.getIssn() + 
                    		"\nFrequency:" + journal.getFrequency() + "\nIssue Price:" + journal.getIssuePrice();
                    }
            }

                JOptionPane.showMessageDialog(null, "Subscriber Info:\n" + subscriberInfo + "\nJournal Info:\n" + journalInfo,
                        "Subscription Information", JOptionPane.INFORMATION_MESSAGE);
                
                
                inputPanel3.add(new JLabel("Start Month:"));
                inputPanel3.add(startMonthField);
                inputPanel3.add(new JLabel("Start Year:"));
                inputPanel3.add(startYearField);                
                inputPanel3.add(new JLabel("Personal Discount Ratio: %"));
                inputPanel3.add(discountRatioField);
                inputPanel3.add(new JLabel("Starting Balance:"));
                inputPanel3.add(balanceField);
                inputPanel3.add(new JLabel("Number of copies:"));
                inputPanel3.add(copiesField);
                
                result = JOptionPane.showConfirmDialog(null, inputPanel3,
                        "Subscription Data", JOptionPane.OK_CANCEL_OPTION);
                
                if (result == JOptionPane.OK_OPTION) {
                    
                    try {
                    	int startMonth = Integer.valueOf(startMonthField.getText());
                    	int startYear = Integer.valueOf(startYearField.getText());
                    	double ratio = Integer.valueOf(discountRatioField.getText());
                    	int copies = Integer.valueOf(copiesField.getText());
                    	double balance = Double.valueOf(balanceField.getText());
                    	
                    	int endYear = 0;
                    	int endMonth;
                    	
                    	if(startMonth == 1) {
                    		endMonth = 12;
                    		endYear = startYear;
                    	} else {
                    	endMonth = startMonth - 1;
                    	endYear = startYear + 1;
                    	}
                    	
                   
                    	
                    	DateInfo dates = new DateInfo(startMonth, startYear, endMonth, endYear);
                    	ratio = (100.0 -ratio )/100.0;
                    	
                    	PaymentInfo payment = new PaymentInfo(ratio, balance);
                    	
						Subscription newsub = new Subscription(journal, subscriber, dates, copies, payment);
                    	
						if(distributor.addSubscription(journal, subscriber, newsub) == true) {
                            JOptionPane.showMessageDialog(null, "Subscription has been created. Thank you.", "Success", JOptionPane.INFORMATION_MESSAGE);
						} else {
                            JOptionPane.showMessageDialog(null, "This subscription alreadys exists. Number of copies has been increased.",
                            		"Copy Increase", JOptionPane.INFORMATION_MESSAGE);

						}

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid numeric values.",
                                "Input Error", JOptionPane.ERROR_MESSAGE);
                    }
            }
                
                
                
            }
        });

        JButton SearchSubscribersButton = new JButton("Search Subscribers");
        SearchSubscribersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	JPanel inputPanel = new JPanel(new GridLayout(0, 2));
                JTextField nameField = new JTextField();
                JLabel nameLabel = new JLabel("Subscriber Name:");

                inputPanel.add(nameLabel);
                inputPanel.add(nameField);
                
                
                
                int result = JOptionPane.showConfirmDialog(null, inputPanel,
                        "Enter Journal Information", JOptionPane.OK_CANCEL_OPTION);
                
                if (result == JOptionPane.OK_OPTION) {
                        String name = nameField.getText();

                        Subscriber subscriber = distributor.searchSubscriber(name);
                        
                        if (subscriber == null) {
                            // Handle case when subscriber is not found
                            JOptionPane.showMessageDialog(null, "Subscriber not found!", "Search Result", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            // Display the information of the found subscriber
                            String subscriberInfo = null;
                            if (subscriber instanceof Individual) {
                                Individual individualSubscriber = (Individual) subscriber;
                                subscriberInfo = "Individual Subscriber:\nName: " + individualSubscriber.getName() +
                                        "\nAddress: " + individualSubscriber.getAddress() +
                                        individualSubscriber.getBillingInformation();
                            } else if (subscriber instanceof Corporation) {
                                Corporation corporateSubscriber = (Corporation) subscriber;
                                subscriberInfo = "Corporate Subscriber:\nName: " + corporateSubscriber.getName() +
                                        "\nAddress: " + corporateSubscriber.getAddress() +
                                        corporateSubscriber.getBillingInformation();
                            }     
                            
                            JOptionPane.showMessageDialog(null, "Found Subscriber:\n" + subscriberInfo,
                                    "Search Result", JOptionPane.INFORMATION_MESSAGE);
                        }
                	}
                }
        });
        
        JButton SearchJournalsButton = new JButton("Search Journals");
        SearchJournalsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	JPanel inputPanel = new JPanel(new GridLayout(0, 2));
                JTextField nameField = new JTextField();
                JLabel nameLabel = new JLabel("Journal ISSN:");

                inputPanel.add(nameLabel);
                inputPanel.add(nameField);
                
                
                
                int result = JOptionPane.showConfirmDialog(null, inputPanel,
                        "Enter Journal Information", JOptionPane.OK_CANCEL_OPTION);
                
                if (result == JOptionPane.OK_OPTION) {
                        String name = nameField.getText();

                        Journal journal = distributor.searchJournal(name);
                        
                        if(journal == null) {
                            JOptionPane.showMessageDialog(null, "Journal not found! :(", "Search Result", JOptionPane.INFORMATION_MESSAGE);	 
                        } else {
                       	 JOptionPane.showMessageDialog(null, "Found Journal:\nName: " + journal.getName() + "\nISSN: " + journal.getIssn() +
                                    "\nFrequency: " + journal.getFrequency() + "\nIssue Price: " + journal.getIssuePrice(),
                                    "Search Result", JOptionPane.INFORMATION_MESSAGE);
                        
                        }       
                }
            }
        });
        
        JButton saveStateButton = new JButton("Save State");
        saveStateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                distributor.saveState("database.bat");
            }
        });

        JButton loadStateButton = new JButton("Load State");
        loadStateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                distributor.loadState("database.bat");
            }
        });
        
        JButton listAllSendingOrdersButton = new JButton("List All Sending Orders");
        listAllSendingOrdersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel inputPanel = new JPanel(new GridLayout(0, 2));
                JTextField monthField = new JTextField();
                JTextField yearField = new JTextField();
                
                inputPanel.add(new JLabel("Month:"));
                inputPanel.add(monthField);
                inputPanel.add(new JLabel("Year:"));
                inputPanel.add(yearField);
      
                int result = JOptionPane.showConfirmDialog(null, inputPanel, "Enter Information", JOptionPane.OK_CANCEL_OPTION);

                if (result == JOptionPane.OK_OPTION) {
                    int month = Integer.parseInt(monthField.getText());
                    int year = Integer.parseInt(yearField.getText());
                    distributor.listAllSendingOrders(month, year);
                }
            }
        });

        JButton listSendingOrdersButton = new JButton("List Sending Orders");
        listSendingOrdersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel inputPanel = new JPanel(new GridLayout(0, 2));
                JTextField issnField = new JTextField();
                JTextField monthField = new JTextField();
                JTextField yearField = new JTextField();

                inputPanel.add(new JLabel("ISSN:"));
                inputPanel.add(issnField);
                inputPanel.add(new JLabel("Month:"));
                inputPanel.add(monthField);
                inputPanel.add(new JLabel("Year:"));
                inputPanel.add(yearField);

                int result = JOptionPane.showConfirmDialog(null, inputPanel, "Enter Information", JOptionPane.OK_CANCEL_OPTION);

                if (result == JOptionPane.OK_OPTION) {
                    String issn = issnField.getText();
                    int month = Integer.parseInt(monthField.getText());
                    int year = Integer.parseInt(yearField.getText());
                    distributor.listSendingOrders(issn, month, year);
                }
            }
        });

        JButton incompletePaymentsButton = new JButton("Incomplete Payments");
        incompletePaymentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                distributor.IncompletePayments();
            }
        });

        JButton listSubscriptionsByNameButton = new JButton("List Subscriptions by Name");
        listSubscriptionsByNameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel inputPanel = new JPanel(new GridLayout(0, 2));
                JTextField nameField = new JTextField();

                inputPanel.add(new JLabel("Subscriber Name:"));
                inputPanel.add(nameField);

                int result = JOptionPane.showConfirmDialog(null, inputPanel, "Enter Information", JOptionPane.OK_CANCEL_OPTION);

                if (result == JOptionPane.OK_OPTION) {
                    String subscriberName = nameField.getText();
                    distributor.listSubscriptions(subscriberName);
                }
            }
        });

        JButton listSubscriptionsByISSNButton = new JButton("List Subscriptions by ISSN");
        listSubscriptionsByISSNButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel inputPanel = new JPanel(new GridLayout(0, 2));
                JTextField issnField = new JTextField();

                inputPanel.add(new JLabel("ISSN:"));
                inputPanel.add(issnField);

                int result = JOptionPane.showConfirmDialog(null, inputPanel, "Enter Information", JOptionPane.OK_CANCEL_OPTION);

                if (result == JOptionPane.OK_OPTION) {
                    String issn = issnField.getText();
                    distributor.listSubscriptions(issn, false);
                }
            }
        });
        
        JButton reportButton = new JButton("Request Report");
        reportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JPanel inputPanel = new JPanel(new GridLayout(0, 2));
                JTextField expiryMonthField = new JTextField();
                JTextField expiryYearField = new JTextField();
                JTextField annual1Field = new JTextField();
                JTextField annual2Field = new JTextField();

                inputPanel.add(new JLabel("Expiry Month:"));
                inputPanel.add(expiryMonthField);
                inputPanel.add(new JLabel("Expiry Year:"));
                inputPanel.add(expiryYearField);
                inputPanel.add(new JLabel("Yearly Income Range | From:"));
                inputPanel.add(annual1Field);
                inputPanel.add(new JLabel("Yearly Income Range | To  :"));
                inputPanel.add(annual2Field);

                
                int result = JOptionPane.showConfirmDialog(null, inputPanel, "Enter Information", JOptionPane.OK_CANCEL_OPTION);
                
                int expiryMonth;
                int expiryYear;
                int annual1;
                int annual2;
                
                if (result == JOptionPane.OK_OPTION) {
                    
                	try {
                	expiryMonth = Integer.valueOf(expiryMonthField.getText());
                	expiryYear = Integer.valueOf(expiryYearField.getText());
                	annual1 = Integer.valueOf(annual1Field.getText());
                	annual2 = Integer.valueOf(annual2Field.getText());
                	} catch(NumberFormatException ex) {		 
               		 JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid numeric values.",
                             "Input Error", JOptionPane.ERROR_MESSAGE);
               		 return;
            	 }

                	distributor.report(expiryMonth, expiryYear, annual1, annual2);
                	
                }
            }
        });
        
        
        JButton topUpButton = new JButton("Top Up a Subscription");
        topUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	JPanel inputPanel = new JPanel(new GridLayout(0, 2));
            	JPanel inputPanel2 = new JPanel(new GridLayout(0, 2));
            	JPanel inputPanel3 = new JPanel(new GridLayout(0, 2));

                JTextField nameField = new JTextField();
                JTextField issnField = new JTextField();
                JTextField moneyField = new JTextField();

                
                String subscriberInfo = null;
                String journalInfo = null;

                Subscriber subscriber = null;
                Journal journal = null;

                inputPanel.add(new JLabel("Subscriber Name:"));
                inputPanel.add(nameField);
               

                int result = JOptionPane.showConfirmDialog(null, inputPanel,
                        "Enter Subscriber's Information", JOptionPane.OK_CANCEL_OPTION);

                if (result == JOptionPane.OK_OPTION) {
                    	String name = nameField.getText();
                        subscriber = distributor.searchSubscriber(name);

                        if (subscriber == null) {
                            JOptionPane.showMessageDialog(null, "Subscriber not found!", "Search Result", JOptionPane.INFORMATION_MESSAGE);
                            return;
                        } else {
                            if (subscriber instanceof Individual) {
                                Individual individualSubscriber = (Individual) subscriber;
                                subscriberInfo = "Individual Subscriber:\nName: " + individualSubscriber.getName() +
                                        "\nAddress: " + individualSubscriber.getAddress() +
                                        individualSubscriber.getBillingInformation();
                            } else if (subscriber instanceof Corporation) {
                                Corporation corporateSubscriber = (Corporation) subscriber;
                                subscriberInfo = "Corporate Subscriber:\nName: " + corporateSubscriber.getName() +
                                        "\nAddress: " + corporateSubscriber.getAddress() +
                                        corporateSubscriber.getBillingInformation();
                            }
                        }
                        
                        
                }
                
                inputPanel2.add(new JLabel("Journal ISSN:"));
                inputPanel2.add(issnField);
                
                result = JOptionPane.showConfirmDialog(null, inputPanel2,
                        "Enter Journal's Information", JOptionPane.OK_CANCEL_OPTION);
                
                
                if (result == JOptionPane.OK_OPTION) {
                    String issn = issnField.getText();
                    journal = distributor.searchJournal(issn);
                    
                    if (journal == null) {
                        JOptionPane.showMessageDialog(null, "Journal not found! :(", "Search Result", JOptionPane.INFORMATION_MESSAGE);	
                        return;
                } else {
                    journalInfo = "Journal: \nName:" + journal.getName() + "\nISSN:" + journal.getIssn() + 
                    		"\nFrequency:" + journal.getFrequency() + "\nIssue Price:" + journal.getIssuePrice();
                    }
            }


           Subscription subscription = distributor.findSubscription(subscriber, journal);     
           if (subscription == null) {
               JOptionPane.showMessageDialog(null, "No such subscription info found.",
                       "Subscription Not Found", JOptionPane.INFORMATION_MESSAGE);
               return;
           }else {
                  JOptionPane.showMessageDialog(null, "Subscriber Info:\n" + subscriberInfo + "\nJournal Info:\n" + journalInfo +
                		  "\nCurrent Balance of this subscription: " + subscription.getPayment().getReceivedPayment() + 
                		  "\nPrice per issue (including discount if exists): " + (subscription.getJournal().getIssuePrice()*
                				  subscription.getPayment().getDiscountRatio()),
                        "Subscription Information", JOptionPane.INFORMATION_MESSAGE);     }         
           
           
           inputPanel3.add(new JLabel("Transferred Money Amount:"));
           inputPanel3.add(moneyField); 
           
           result = JOptionPane.showConfirmDialog(null, inputPanel3, "Enter Information", JOptionPane.OK_CANCEL_OPTION);
           
           int amount;

           if (result == JOptionPane.OK_OPTION) {
               
           	try {
           	amount = Integer.valueOf(moneyField.getText());
           	} catch(NumberFormatException ex) {		 
          		 JOptionPane.showMessageDialog(null, "Invalid input. Please enter valid numeric values.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
          		 return;
           	}

           	subscription.acceptPayment(amount);
            JOptionPane.showMessageDialog(null, "Money Received.\nNew Balance:" + subscription.getPayment().getReceivedPayment(),
                    "Top Up Success", JOptionPane.INFORMATION_MESSAGE);
           	
           }
           
           
            }
        });
        
        panel.add(addSubscriberButton);
        panel.add(addJournalButton);
        panel.add(addSubscriptionButton);
        panel.add(saveStateButton);
        panel.add(loadStateButton);
        panel.add(SearchJournalsButton);
        panel.add(SearchSubscribersButton);
        panel.add(listAllSendingOrdersButton);
        panel.add(listSendingOrdersButton);
        panel.add(incompletePaymentsButton);
        panel.add(listSubscriptionsByNameButton);
        panel.add(listSubscriptionsByISSNButton);
        panel.add(topUpButton);
        panel.add(reportButton);

        
        frame.setVisible(true);
    }
	
	
}
