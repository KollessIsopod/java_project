package projectPackage;
import java.io.Serializable;

public class PaymentInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private final double discountRatio;
	private double receivedPayment = 0;
	
	public PaymentInfo(double discountRatio, double receivedPayment) {
		this.discountRatio = discountRatio;
		this.receivedPayment = receivedPayment;
	}

	public double getReceivedPayment() {
		return receivedPayment;
	}

	public void setReceivedPayment(double receivedPayment) {
		this.receivedPayment = receivedPayment;
	}

	public double getDiscountRatio() {
		return discountRatio;
	}
	
	public void increasePayment(double amount) {
		
		if(amount<0) {
			System.out.println("Top up unsuccessful. Kept balance:" + this.receivedPayment);			
			return;
		}
		
		this.receivedPayment += amount;
		
		System.out.println("Top up successful. New balance:" + this.receivedPayment);

		
	}

	public String getPayment() {
		return "Discount Ratio=" + discountRatio + "| Current Balance=" + receivedPayment;
	}
	
	
	
}
