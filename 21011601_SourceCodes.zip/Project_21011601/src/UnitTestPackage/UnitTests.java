package UnitTestPackage;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import projectPackage.*;

public class UnitTests {

    @Test
    public void DistributorInvalidData() {
    	Journal journal = new Journal("name","issn",1,1.1);
        Distributor instance = new Distributor();
        instance.addJournal(journal);
        assertEquals(false, instance.addJournal(journal));
    }

    @Test
    public void DistributorValidData() {
    	Journal journal = new Journal("name","issn",1,1.1);
    	Distributor instance = new Distributor();
    	instance.addJournal(journal);
        assertEquals(journal, instance.searchJournal(journal.getIssn()));
    }

    @Test
    public void IndividualValidData() {
    	Individual instance = new Individual("name", "address", "cardNo",12, 2024, 100);
        assertEquals("address", instance.getAddress());
    }

    @Test
    public void IndividualValidData2() {
    	Individual instance = new Individual("name", "address", "cardNo",12, 2024, 100);
        assertEquals("name", instance.getName());

    }
    
    @Test
    public void CorporationValidData() {
    	Corporation instance = new Corporation("name", "address", 123,123,1,12,2024,"bankname");
        assertEquals("address", instance.getAddress());

    }
    
    @Test
    public void CorporationValidData2() {
    	Individual instance = new Individual("name", "address", "cardNo",12, 2024, 100);
        assertEquals("name", instance.getName());

    }

    @Test
    public void PaymentInfoValidData() {
    	PaymentInfo instance = new PaymentInfo(0.7, 50);
        assertEquals(0.7, instance.getDiscountRatio(), 0);

    }
    
	@Test
    public void PaymentInfoInvalidData() {
    	PaymentInfo instance = new PaymentInfo(0,5);
    	instance.increasePayment(-20);
        assertEquals(5, instance.getReceivedPayment(), 0);

    }
    
	@Test
    public void JournalValidData() {
    	Journal instance = new Journal("name","issn",1,1.1);
    	assertEquals(1.1, instance.getIssuePrice(), 0);
    }
    
	@Test
    public void JournalValidData2() {
    	Journal instance = new Journal("name","issn",1,1.1);
    	assertEquals("issn", instance.getIssn());
    }

}
