I have already prepared some database for testing the project, so I've decided to include them in the zip file too.

Kemal Ata Türkoğlu
21011601